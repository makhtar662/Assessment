const router = require("express").Router();
const controllers = require("../../controllers");

router.get("/", controllers.persons.getAll);

router.get("/:person_id", controllers.persons.getOne);

router.post("/", controllers.persons.add);

router.put("/:person_id", controllers.persons.add);

router.delete("/:person_id", controllers.persons.deletePerson);

module.exports = router;
