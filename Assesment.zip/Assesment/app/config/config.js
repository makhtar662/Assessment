const _ = require("lodash");
require("./logging");
const defaults = require("./defaults");

const env = process.env.NODE_ENV || "development";

const config = {
  development: {
    db: {
      username: "postgres",
      password: "root",
      database: "persondb",
      host: "127.0.0.1",
      port: 5432,
      dialect: "postgres",
      logging: global.cli.logQuery,
      client: "pg",
    },
    isProduction: false,
    port: 7000,
    baseUrl: "http://localhost:7000",
  },
  production: {
    db: {
      database: "persondb",
      username: "root",
      password: "root",
      dialect: "mysql",
      logging: global.cli.logQuery,
    },
    isProduction: true,
  },
  test: {
    db: {
      database: "persondb",
      username: "root",
      password: "root",
      dialect: "mysql",
      logging: global.cli.logQuery,
    },
  },
};

module.exports = _.defaultsDeep(defaults, config[env]);
