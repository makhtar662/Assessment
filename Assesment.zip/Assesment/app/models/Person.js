const moment = require("moment");
const _ = require("lodash");
const helpers = require("../helpers");

module.exports = (sequelize, DataTypes) => {
  const { Op } = sequelize;
  const modelAttributes = {
    id: {
      type: DataTypes.INTEGER,
      autoIncrement: true,
      primaryKey: true,
      allowNull: false,
    },
    name: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    surname: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    password: {
      type: DataTypes.STRING(100),
      validate: {
        notEmpty: {
          args: true,
          msg: "Password can not be empty.",
        },
      },
    },
    age: {
      type: DataTypes.STRING(50),
    },
    email: {
      type: DataTypes.STRING(100),
      allowNull: false,
      isEmail: true,
      validate: {
        notEmpty: {
          args: true,
          msg: "Email can not be empty.",
        },
      },
    },
    phone: {
      type: DataTypes.STRING(20),
    },
    address: {
      type: DataTypes.STRING(255),
    },
    gender: {
      type: DataTypes.STRING(50),
    },
    bio: {
      type: DataTypes.TEXT,
    },
    createdAt: {
      type: DataTypes.DATE,
      defaultValue: DataTypes.NOW,
    },
    updatedAt: {
      type: DataTypes.DATE,
      defaultValue: DataTypes.NOW,
    },
    deletedAt: { type: DataTypes.DATE },
    deletedTimestamp: {
      type: DataTypes.BIGINT,
      defaultValue: 0,
      allowNull: false,
    },
  };

  const Person = sequelize.define("Person", modelAttributes, {
    tableName: "Persons",
    timestamps: true,
    paranoid: true,
  });

  Person.attributes = modelAttributes;

  Person.save = async (params, transaction = null) => {
    try {
      const data = helpers.seql.getRawParams(params, modelAttributes);
      if (data.password && !_.isEmpty(data.password)) {
        data.password = await helpers.auth.encryptPassword(data.password);
      } else {
        delete data.password;
      }
      if (!data.id) {
        return global.db.Person.create(data, { transaction });
      }

      await global.db.Person.update(
        data,
        { where: { id: data.id } },
        { transaction }
      );
      return global.db.Person.getOne(data);
    } catch (e) {
      global.cli.log("model:Person: error while saving person: ", e);
      throw new Error(e);
    }
  };

  Person.getPersons = async (params) => {
    try {
      let personWhere = {};

      if (params.name) {
        personWhere.name = params.name;
      }
      if (params.id) {
        personWhere.is = params.id;
      }

      return global.db.Person.findAll({
        where: personWhere,
      });
    } catch (e) {
      global.cli.log("model:Person: error while getting persond: ", e);
      throw new Error(e);
    }
  };

  Person.getPerson = async (personId) => {
    try {
      const params = {
        id: personId,
      };
      const persons = await global.db.Person.getPersons(params);
      return _.first(persons);
    } catch (e) {
      global.cli.log("model:Person: error while getting person: ", e);
      throw new Error(e);
    }
  };

  return Person;
};
