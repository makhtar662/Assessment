/* eslint no-restricted-globals: 0 */

const _ = require("lodash");
const constants = require("../constants");

exports.getRawParams = (dataParams, attributes) => {
  const where = {};
  _.each(_.keys(dataParams), (key) => {
    if (attributes[key]) {
      where[key] = dataParams[key];
    }
  });
  return where;
};

exports.getPaginationOptions = (params = {}) => {
  if (
    (params.limit && params.limit === constants.pagination.ALL) ||
    !params.limit
  ) {
    return {};
  }
  const pagination = { limit: constants.pagination.DEFAULT_LIMIT, offset: 0 };
  if (params.limit && !isNaN(params.limit)) {
    pagination.limit = parseInt(params.limit, 10);
  }
  if (params.page && !isNaN(params.page)) {
    pagination.offset = (parseInt(params.page, 10) - 1) * pagination.limit;
  }
  return pagination;
};

exports.generateSearchQuery = (dataParams, attributes) => {
  const where = {};
  _.each(_.keys(dataParams), (key) => {
    if (attributes[key]) {
      where[key] = { $iLike: `%${dataParams[key]}%` };
    }
  });
  return where;
};
