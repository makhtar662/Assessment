const router = require("express").Router();
const person = require("./person");

router.use("/", person);

module.exports = router;
