/* eslint no-restricted-globals: 0 */

module.exports = async (req, res, next) => {
  try {
    if (!req.params.person_id || isNaN(req.params.person_id)) {
      next();
      return;
    }
    req.loadedPerson = await global.db.Person.getOne({
      id: req.params.person_id,
    });
    if (!req.loadedPerson) {
      res.status(404).json({ message: "Person not found." });
      return;
    }
    next();
  } catch (e) {
    global.cli.log("middleware: error while loading person: ", e);
    res.status(500).json({
      message: `middleware: error while loading person : ${e.message}`,
    });
  }
};
