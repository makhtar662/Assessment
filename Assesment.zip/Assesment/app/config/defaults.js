module.exports = {
  db: {
    username: "postgres",
    password: "root",
    database: "persondb",
    host: "127.0.0.1",
    port: 5432,
    dialect: "postgres",
    logging: false,
  },
  isProduction: false,
  port: 7000,
  baseUrl: "http://localhost:7000",
};
