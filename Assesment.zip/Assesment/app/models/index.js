const Sequelize = require("sequelize");
const knex = require("knex");
const _ = require("lodash");
const config = require("../config/config");
const helpers = require("../helpers");

const db = {
  sequelize: new Sequelize(
    config.db.database,
    config.db.name,
    config.db.password,
    config.db
  ),
};

db.Person = db.sequelize.import("./Person");

Object.keys(db).forEach((modelName) => {
  if (typeof db[modelName].associate === "function") {
    db[modelName].associate(db);
  }

  const model = db[modelName];

  model.getOne = async (params) => {
    try {
      const result = await model.getAll(params, false);
      return (result && _.first(result)) || null;
    } catch (e) {
      global.cli.log(`model: error while getOne in ${modelName}: `, e);
      throw new Error(e.message);
    }
  };

  model.getAll = (params, getCount = true) => {
    try {
      const where = helpers.seql.getRawParams(params, model.attributes);
      if (getCount) {
        return model.findAndCountAll({ where });
      }
      return model.findAll({ where });
    } catch (e) {
      global.cli.log(`model: error while getAll in ${modelName}: `, e);
      throw new Error(e.message);
    }
  };

  if (!model.delete) {
    model.delete = async (id, transaction = null) => {
      try {
        if (model.attributes.deletedTimestamp) {
          await model.update(
            { deletedTimestamp: Date.now() },
            { where: { id } },
            { transaction }
          );
        }
        await model.destroy({ where: { id } }, transaction);
      } catch (e) {
        global.cli.log(`model: error while delete in ${modelName}: `, e);
        throw new Error(e.message);
      }
    };
  }

  if (!model.save) {
    model.save = async (params, transaction = null) => {
      try {
        const data = helpers.seql.getRawParams(params, model.attributes);

        if (!data.id) {
          return model.create(data, { transaction });
        }
        await model.update(data, { where: { id: data.id } }, { transaction });
        return model.getOne({ id: data.id });
      } catch (e) {
        global.cli.log(
          `model: error while saving data in ${modelName}: `,
          e.message
        );
        throw new Error(e.message);
      }
    };
  }
});

db.knex = knex({
  client: config.db.client,
  connection: {
    host: config.db.host,
    user: config.db.name,
    password: config.db.password,
    database: config.db.database,
    port: config.db.port,
  },
});

module.exports = db;
