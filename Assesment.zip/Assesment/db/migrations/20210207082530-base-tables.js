const fs = require("fs");
const _ = require("lodash");
const db = require("../../app/models");
const knex = db.knex;

module.exports = {
  up: (queryInterface, Sequelize) => {
    const sql = fs
      .readFileSync(__dirname + "/../schemas/initial-db.sql")
      .toString();
    return knex.raw(sql);
  },

  down: async (queryInterface, Sequelize) => {
    const tables = await knex.raw(`
      SELECT * FROM pg_catalog.pg_tables 
      where tableowner = \'postgres\' and schemaname = \'public\';
    `);
    const SequelizeMetaTableName = "SequelizeMeta";
    const tableDropPromises = _.map(tables.rows, (table) => {
      if (table.tablename === SequelizeMetaTableName) {
        return Promise.resolve(null);
      }
      return knex.schema.dropTableIfExists(table.tablename);
    });
    return Promise.all(tableDropPromises);
  },
};
