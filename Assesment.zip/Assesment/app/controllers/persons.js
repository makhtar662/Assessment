const _ = require("lodash");
const { Op } = global.db.sequelize;

module.exports.add = async (req, res) => {
  try {
    const params = req.body;

    const savedPerson = await global.db.Person.save(params);
    res.status(201).json({ savedPerson });
  } catch (e) {
    global.cli.log(
      `controller: error while ${
        req.method === "POST" ? "adding" : "updating"
      } person: `,
      e
    );
    res.status(500).json({ message: e.message });
  }
};

module.exports.getAll = async (req, res) => {
  try {
    const params = req.query;

    const persons = await global.db.Person.getPersons(params);

    res.json({ persons });
  } catch (e) {
    global.cli.log("controller: error while getting persons: ", e);
    res.status(500).json({ message: e.message });
  }
};

module.exports.getOne = async (req, res) => {
  try {
    const person = await global.db.Person.getPerson();
    res.json({ person });
  } catch (e) {
    global.cli.log("controller: error while getting person: ", e);
    res.status(500).json({ message: e.message });
  }
};

module.exports.deletePerson = async (req, res) => {
  try {
    await global.db.Person.delete(req.params.person_id);
    res.status(200).json({});
  } catch (e) {
    global.cli.log("error while in deletePerson: ", e);
    res.status(500).json({ message: e.message });
  }
};
