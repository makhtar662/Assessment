CREATE TABLE "Persons"
(
	"id" serial NOT NULL,
	"name" varchar(255) NOT NULL,
	"surname" varchar(255) NOT NULL,
	"password" varchar(100),
	"age" varchar(50),
	"email" varchar(100) NOT NULL,
	"phone" varchar(20),
	"address" varchar(255),
	"gender" varchar(50),
	"bio" text,
	"createdAt" timestamptz NOT NULL,
	"updatedAt" timestamptz,
	"deletedAt" timestamptz,
	"deletedTimestamp" bigint NOT NULL DEFAULT '0',
	CONSTRAINT Users_pk PRIMARY KEY ("id")
)
WITH (
  OIDS=FALSE
);

