const bcrypt = require("bcrypt");
const config = require("../../app/config/config");

async function encryptPassword(password) {
  return bcrypt.hash(password);
}

async function decryptPassword(password, databasePassword) {
  return bcrypt.compare(password, databasePassword);
}

module.exports = {
  encryptPassword,
  decryptPassword,
};
